BOT_TOKEN = 'your_bot_token_here'
OWNER_ID = 123456789