# main bot logic
print('Bot started')